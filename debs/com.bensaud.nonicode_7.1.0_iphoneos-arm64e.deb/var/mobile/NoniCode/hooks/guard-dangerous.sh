#!/usr/bin/env bash
# guard-dangerous.sh - check a shell command against kwwk's red-tier rules.
# Usage: guard-dangerous.sh '<command>'      (or pipe the command on stdin)
# Exit:  0 = allowed, 2 = needs the user's explicit confirmation, 64 = usage
# With KWWK_CONFIRMED=1 the guard allows everything: set it only after the user said yes.
set -u

usage() { sed -n '2,5p' "$0" | sed 's/^# \{0,1\}//'; }

cmd="${1:-}"
case "$cmd" in -h|--help) usage; exit 0 ;; esac
if [ -z "$cmd" ] && [ ! -t 0 ]; then cmd=$(cat); fi
if [ -z "$cmd" ]; then usage >&2; exit 64; fi

if [ "${KWWK_CONFIRMED:-0}" = "1" ]; then
  echo "guard: KWWK_CONFIRMED=1, allowing: $cmd" >&2
  exit 0
fi

SP='[[:space:]]'
START="(^|[;&|(]|$SP)"
reasons=()

check() { # regex, reason
  if printf '%s\n' "$cmd" | grep -Eiq -- "$1"; then reasons+=("$2"); fi
}

check_both() { # regex A, regex B, reason (both must match)
  if printf '%s\n' "$cmd" | grep -Eiq -- "$1" && printf '%s\n' "$cmd" | grep -Eiq -- "$2"; then
    reasons+=("$3")
  fi
}

SYSPATH='(/System(/|[[:space:]]|$)|/usr/(bin|lib|libexec|sbin|share)|/private/preboot|\.jbroot|/Library/LaunchDaemons)'
WRITEVERB="${START}(rm|mv|cp|ln|tee|dd|chmod|chown|touch|install|rsync)$SP|sed$SP+-[[:alpha:]]*i"

check "${START}rm$SP+([^;&|]*$SP)?(-[[:alpha:]]*r[[:alpha:]]*|--recursive)($SP|\$)" \
  'recursive delete: use scripts/safe-rm.sh instead of rm -r'
check_both "$SYSPATH" "$WRITEVERB" \
  'modifies a system or jailbreak path'
check ">>?$SP*(/System/|/usr/|/private/preboot|/Library/LaunchDaemons|[^[:space:]]*\.jbroot)" \
  'redirects output into a system or jailbreak path'
check "${START}(chmod|chown|chgrp)$SP+([^;&|]*$SP)?(-[[:alpha:]]*R[[:alpha:]]*|--recursive)($SP|\$)" \
  'recursive permission or owner change'
check "${START}dd$SP.*of=/dev/" \
  'dd writing to a device'
check "${START}(mkfs|newfs)[[:alnum:]._]*($SP|\$)" \
  'formats a filesystem'
check ">$SP*/dev/(r?disk|sd)" \
  'writes to a block device'
check "${START}dpkg$SP+([^;&|]*$SP)?(-r|-P|--remove|--purge)($SP|\$)" \
  'removes or purges a package'
check "${START}apt(-get)?$SP+(remove|purge|autoremove)" \
  'removes packages'
check "${START}(reboot|halt|shutdown|ldrestart)($SP|\$)|userspace$SP+reboot|launchctl$SP+reboot" \
  'reboots or restarts the device'
check "${START}sbreload($SP|\$)|killall$SP+([^;&|]*$SP)?(SpringBoard|backboardd|launchd|mediaserverd|cfprefsd)" \
  'respring or kills a system process'
check "launchctl$SP+(unload|remove|bootout)" \
  'changes launch daemons'
check "(curl|wget)[^|]*\|$SP*(sudo$SP+)?(ba|z)?sh" \
  'pipes a download into a shell'
check "${START}git$SP+push$SP+([^;&|]*$SP)?(--force|--force-with-lease|-f)($SP|\$)" \
  'force push'
check "${START}git$SP+reset$SP+([^;&|]*$SP)?--hard" \
  'git reset --hard discards work'
check "${START}git$SP+clean$SP+-[[:alpha:]]*[fd]" \
  'git clean deletes untracked files'

if [ "${#reasons[@]}" -eq 0 ]; then exit 0; fi

{
  echo "⚠️  guard: this command needs the user's explicit confirmation:"
  for r in "${reasons[@]}"; do printf '   - %s\n' "$r"; done
  printf '   command: %s\n' "$cmd"
  echo "   Ask the user, back up with scripts/backup.sh, then run it again with KWWK_CONFIRMED=1."
} >&2
exit 2
