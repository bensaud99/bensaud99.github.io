---
name: coding-traps
description: Use before writing any code involving dates, times, epochs, units, mutation vs copy, async/await, floats or money, sort comparators, division/modulo, regex or strings, familiar-API traps, closures in loops, boolean logic, truthiness, or computed loop bounds. Find your section and follow its rows.
---

# Coding traps

Find your section, follow its rows. No row covers your case and the behavior is load-bearing? Run a one-line REPL probe (`node -e` / `python -c`) and paste the output — never guess.

## Computed bounds (pagination, chunking, windows, offsets)

- Before writing any loop, slice, or index arithmetic with COMPUTED bounds: pick a concrete input of length 3 plus the empty and length-1 cases, and write the expected iterations/outputs as a one-line comment.
  ```
  // len=10,size=3 -> [0:3][3:6][6:9][9:10] = 4 chunks; len=0 -> 0 chunks
  ```
- Then write the code and check it against the trace. If code and trace disagree, the trace wins — fix the code, not the comment.
- Annotate every range's inclusivity as `[a, b)`.

## Dates & times

- Never add 86400s/24h for "next day" where local time matters -> use addDays / timedelta(days=1) / tz-aware arithmetic (DST breaks fixed offsets).
- Month arithmetic overflows on day 31: state in a comment what Jan 31 + 1 month must produce, then pick the API.
- JS: months are 0-indexed (`new Date(2024, 0, 15)` = Jan 15); getDay() = weekday, getDate() = day-of-month.
- JS parsing: `new Date('2024-01-15')` = UTC midnight; `new Date(2024, 0, 15)` = LOCAL midnight — mixing shifts dates a day.
- Year format token depends on the library family: Java/date-fns/Luxon (LDML tokens): yyyy, never YYYY (uppercase = week-numbering year, wrong near New Year). Moment/Day.js: YYYY IS the calendar year. Python strftime: %Y (%G is ISO week-year). Unsure which family? Probe 2024-12-30 with both tokens and paste the output.
- Python: never compare naive and aware datetimes; `datetime.utcnow()` is naive -> use `datetime.now(timezone.utc)`.
- Date-range filters on timestamps: `ts >= day AND ts < nextDay`, never `<= endOfDay`.
- After writing date arithmetic, trace three dates in a comment: Jan 31, Dec 31, a DST transition.

## Epochs & units

- Digit count: 10 = seconds, 13 = ms, 16 = µs, 19 = ns. JS Date.now()/getTime() = ms; new Date(n) expects ms; Python time.time() = s; JWT exp/iat = s; System.currentTimeMillis() = ms; Go Unix() = s.
- Name the unit into the variable: `expiresAtSec`, `timeoutMs`, `maxBytes`, `amountCents`, `angleRad`. Every *1000 or /1000 gets a comment naming both units.
- When passing a bare numeric time/size argument to an API, state the API's unit in an inline comment at the call site (`setTimeout(fn, 30_000 /* ms */)`).

## Mutation vs copy

- JS mutating: sort, reverse, splice, push/pop/shift/unshift, fill. Copying: toSorted, toReversed, toSpliced (ES2023), slice, concat, spread.
- Python: list.sort()/.reverse() mutate AND return None. sorted() returns a NEW list; reversed() returns a lazy ONE-SHOT iterator over the ORIGINAL.
- Python: `x = y` never copies; .copy()/list(y)/y[:] are SHALLOW -> copy.deepcopy for nested structures.
- `def f(x, acc=[])` persists across calls -> `acc=None` sentinel. `[[0]*n]*m` aliases every row -> comprehension. JSON round-trip drops Dates/undefined -> structuredClone.
- Before mutating anything that arrived as a parameter or came from shared state: write one line naming who else holds a reference; if anyone might, copy first.

## Async

- Every async call is awaited, `return await`-ed inside try/catch, .then-chained, or explicitly `void`-ed with `// fire-and-forget`. After editing async code: Grep the file for each async function name; for every hit not preceded by await/return/void on that line, justify it in one line.
- Never pass an async callback to forEach/filter/reduce -> `for..of` + await (sequential) or `await Promise.all(items.map(...))` (parallel); state which one and why.
- Never branch on an un-awaited call: `if (asyncFn())` is always truthy.
- A value read BEFORE an await and written AFTER it may be stale — re-read after the await.

## Floats & money

- Never ==/=== computed floats -> tolerance (`Math.abs(a-b) < 1e-9`, math.isclose, pytest.approx) or integers.
- Money is ALWAYS integer minor units or Decimal; before finishing, grep the diff for arithmetic on price/amount/total/fee/balance and confirm no binary floats. `toFixed()` returns a STRING.

## Sort

- JS .sort() without a comparator is lexicographic: `[10,9,1].sort()` -> `[1,10,9]`. Always pass a comparator (or comment `// lexicographic intended`).
- Comparators return NUMBERS, never booleans: rewrite bare `>` as `a - b` (finite numbers), `localeCompare` (user-facing strings), or -1/0/1. `.sort()` MUTATES -> toSorted for a copy.

## Division & modulo

- Python // and % FLOOR (-1 % 5 = 4); JS/Java/C/Go/Rust % TRUNCATES (-1 % 5 = -1). Dividend can be negative? Trace one concrete negative value in a comment; nonnegative modulo = `((x % n) + n) % n`.
- JS numbers corrupt integers above 2^53: 64-bit IDs travel as STRINGS through JSON and JS.

## Regex & strings

- After writing any non-literal regex: probe it with `node -e`/`python -c` against one intended match, one near-miss, and the empty string — paste the outputs.
- Escape literal dots; anchor validations `^...$` (Python re.match anchors start only -> re.fullmatch); JS `str.replace(string, x)` replaces FIRST only -> replaceAll or /g; a reused /g regex keeps lastIndex state; `$` in replacements is special -> `$$`.
- Python `str.split()` (no arg) collapses whitespace runs — not `split(' ')`. JS `'👍'.length === 2` — use `[...str]` for user-visible truncation.

## Truthiness vs explicit null check

- Truthiness guards are allowed only on values whose type is exactly boolean, or object/array references where 'missing' is the only falsy possibility.
- For any value that could legitimately be 0, '', false, NaN, or empty: compare explicitly — `x === undefined`, `x == null`, `x is None`, `len(xs) == 0`.
- JS defaults use `??`, never `||`, unless a comment states why falsy-but-present values must also be replaced.
- To distinguish 'key missing' from 'key present with null/None': use `in` / Object.hasOwn / a dict sentinel — never `.get()` truthiness.

## Familiar-API traps

- `['1','7','11'].map(parseInt)` -> `[1, NaN, 3]` (index becomes radix) -> use `Number` or `x => parseInt(x, 10)`.
- `typeof null === 'object'`; `NaN !== NaN` -> Number.isNaN. JSON.stringify drops undefined/functions; NaN/Infinity become null; Dates do not round-trip.
- Python `is` only for None/True/False. `Array(3).map(f)` does nothing (holes) -> `Array.from({length: 3}, f)`.

## Closures in loops

- Deferred execution captures VARIABLES, not values: JS -> `let` in the for-header, never `var`; Python -> `lambda i=i: ...` or functools.partial; Go <1.22 -> `i := i`. State in one line which value each closure sees at CALL time.

## Boolean logic

- Negation mixed with &&/|| (or `not` with and/or), or 3+ clauses: write the truth-table rows where the expression is TRUE (up to 4 rows; more than 4 TRUE rows -> decompose into named booleans first); parenthesize every group; prefer naming the positive concept.
- Branching on a negatively named flag (noCache, disabled, exclude*, skip*): comment what the TRUE branch does in positive words, or introduce a positively named local first.
- Mixed operator categories in one expression (bitwise+comparison, arithmetic in string concat, ?? with ||): parenthesize every subexpression.
