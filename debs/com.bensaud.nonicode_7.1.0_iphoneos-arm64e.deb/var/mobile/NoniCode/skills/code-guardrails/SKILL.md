---
name: code-guardrails
description: Use before the first edit of any file, and after any signature, symbol, return-shape, config-key, route, or enum change. The C1-C15 pre/post-edit checklist plus the named REFERENCE SWEEP procedure. Cite the ID with one line of evidence when an item fires.
---

# Code guardrails (C1-C15 + REFERENCE SWEEP)

You are here because you are about to create or modify a repo file — by Edit, Write, or a shell command that writes files — for the first time since session start or the last compaction.

Checklist — cite the ID with one line of evidence when an item fires; skipping a fired item is a violation.

## Before the FIRST edit of each file

- C1. Read the enclosing function/class plus the import block; file under 250 lines -> Read all of it. A Grep snippet is not a Read. Mandatory even for "obvious one-liners".
- C2. Generated/vendored check: path contains dist/, build/, out/, gen/, target/, node_modules/, vendor/, coverage/, *.min.*, or a lockfile? Do not edit -> find the source or generator, change that, re-run the generator, name the generator command.
- C3. Twin check: Grep the target file/symbol name repo-wide before the first edit. More than one hit defines it? List all candidates and paste the evidence for the live one.
- C4. Constraint check: print `CONSTRAINT CHECK: <path> — none apply` or `CONSTRAINT CHECK: <path> — matches '<constraint>', skipping/asking`.
- C5. Unfamiliar or third-party API with 2+ arguments: paste its real signature before writing the call. Cannot produce it? write `SIGNATURE UNVERIFIED: <fn>` and pick a different API or stop and ask the user for the docs.
- C6. First use of each third-party library this session: read its pinned version from the manifest/lockfile and state `Using <lib> v<N> — writing v<N> idioms.`
- C7. Touching a trap category (dates, epochs, computed bounds, mutation, async, floats/money, sort, division/modulo, regex/strings, familiar APIs, closures in loops, boolean logic, truthiness)? Read the `coding-traps` skill and follow its rows — never guess load-bearing behavior.
- C8. Duplicated-then-adapted block: list every token that had to change; Grep the file with -n for each OLD token; confirm in one line per token that every hit's line number lies OUTSIDE the new block's range.
- C9. Edit with replace_all=true: first Grep the old_string in that file and paste every occurrence; confirm each should change. Never replace_all a string that is not a complete identifier.
- C10. New project-local import: confirm the target exists — Glob the module path or Grep the export (`def <sym>|class <sym>|export .*<sym>`) — and paste the hit.
- C14. Before any Edit that deletes "dead" code: paste all three greps first — (1) bare name repo-wide including non-code files, (2) the name inside quotes for dynamic dispatch, (3) __all__/barrel/plugin/entry-point registrations. Any ambiguous hit -> deprecate instead of delete.
- C15. Replacing more than half a function or file? List the current version's observable behaviors first — every branch, default, side effect, handled error — and state where each survives in the new version.

## After each edit

- C11. Run `git diff -- <file>` — any change on a line you did not intend to touch is corruption: revert and redo the Edit with more surrounding context. Python: `python -m py_compile <file>`. .js/.mjs: `node --check <file>`.
- C12. Changed a signature, symbol name, return shape, config key, route, CLI flag, env var, or enum member? Run REFERENCE SWEEP (below) now — before the next task step.
- C13. New code doing I/O, network, parsing of external input, or multi-step mutation: implement the failure path explicitly, then report `HANDLED FAILURES: <list>` and `NOT HANDLED (by choice): <list + reason>`. An empty failure list on I/O code is a defect.

## REFERENCE SWEEP (named procedure — invoked by C12)

- RS1. Grep the affected symbol's name repo-wide with NO file-type filter (code, configs, YAML, templates, docs, fixtures) — the OLD name if renamed, otherwise the unchanged name of the thing whose contract changed.
- RS2. Paste the hit list as file:line. A zero-hit result is pasted, never asserted.
- RS3. More than 50 hits? Re-run with a word-boundary pattern (`\b<name>\b`) excluding vendored paths (node_modules/, dist/, vendor/); still >50 -> delegate the sweep and disposition the returned list yourself.
- RS4. Disposition every hit in one line each: `updated` or `unaffected — <reason>`. Renames: additionally Grep the name as a string literal (logs, reflection, dynamic dispatch).
- RS5. Enum/union changes: additionally Grep switch/match/if-chains over that type; update every branch set. Do not proceed until every hit is dispositioned.

## Reference

### Your Edit failed with "string not found"
The only permitted next action on that file is a Read of the target region — never a guessed retry, never a whole-file Write. Your memory of the file is provably wrong; the file may have been changed by your own earlier edits, a formatter, or the user.

### You are rewriting instead of editing
Before the rewrite: list the current version's observable behaviors — every branch, default, side effect, handled error — and state where each survives. Any behavior not on the list is one you are deleting unknowingly.
