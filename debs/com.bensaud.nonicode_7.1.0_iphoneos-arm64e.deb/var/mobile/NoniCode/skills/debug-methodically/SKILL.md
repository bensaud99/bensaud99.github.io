---
name: debug-methodically
description: Use when a build, script, app or command fails or behaves wrongly. A fixed loop of reproduce, read, isolate, hypothesise, test, fix and re-check, with the places to look on this phone.
---

# Debugging methodically

Do not guess and patch. Find the cause, fix that, and prove the fix.

## The loop

1. **Reproduce.** Get the failure again with the exact command. Copy the full error text. If you cannot reproduce it, say so before changing anything.
2. **Read the first error.** In a build log, the first error is usually the cause and everything after it is noise. In a crash, read the top frames of the crashing thread.
3. **Isolate.** Make the failing case smaller: one file, one function, one line of a script (`bash -x`). Remove things until the failure disappears, then put the last one back.
4. **Hypothesise.** Write one sentence: "It fails because X". Say what you would see if X were true.
5. **Test the hypothesis** with a command that can prove it wrong. Do not edit code to test a theory if a read-only command will do.
6. **Fix the cause.** The smallest change that removes it. No unrelated clean-ups in the same change.
7. **Re-check.** Run the original failing command, then `scripts/verify.sh`, then the neighbours that could be affected.

If two hypotheses in a row are wrong, stop and re-read the evidence from the start. If you have changed three things and it still fails, undo them and restart from step 1.

## Where to look on this device

| Problem | Look at |
|---|---|
| Shell script | `bash -n script.sh`, then `bash -x script.sh` |
| Theos build | the first `error:` line of `make` output; `$THEOS/sdks`; `echo $THEOS` |
| Swift error | the file and line named; a missing import; an API newer than iOS 16.4 |
| App crashes at launch | `/var/mobile/Library/Logs/CrashReporter/` (newest `.ips`); entitlements via `ldid -e`; `CFBundleExecutable` vs binary name |
| Tweak crash or respring loop | crash reports for `SpringBoard`; the hook you added last |
| "command not found" | `command -v tool`, `echo $PATH`, whether the package is installed (`dpkg -l | grep tool`) |
| "Permission denied" | `ls -l`, `id`, execute bit; do not `chmod -R` your way out of it |
| plist problems | `plutil -lint file.plist` |

## Report format

- **Cause:** one sentence.
- **Evidence:** the line of output that shows it.
- **Fix:** what changed, in which file.
- **Check:** the command you ran afterwards and what it printed.
- **Not verified:** anything you could not test.

## Do not

- Silence an error (`2>/dev/null`, `|| true`, an empty `catch`) to make it go away.
- Change the test or the check so that it passes.
- Say "should work now" without running it.

---

## Debug checklist (D1-D10)

Cite IDs as you go; the ESCALATION LADDER below is mandatory, not optional.

- D1. Reproduce FIRST: write down and run the exact reproduction command; paste its failing output, and quote the line in it that shows the REPORTED symptom (a command failing for an unrelated reason is not a reproduction). The bug is fixed ONLY when that same command, unmodified, is re-run and passes — paste that too. Cannot reproduce? run the user's steps plus the D2 environment checks, write `CANNOT-REPRODUCE: <commands tried -> outputs>`, and ask the user for exact steps — never fix blind.
- D2. "It worked before / stopped working": step 1 is environment re-verification, before touching code. Check: server actually up (`lsof -ti :PORT`), right branch (`git branch --show-current`), package installed (`pip show <X>` / `npm ls <X>`), env var set, artifact rebuilt after the edit. Any environment belief last verified >15 messages ago, or before a compaction, is stale — re-verify with one command.
- D3. CAUSE line before any fix: `CAUSE: <file:line where the bad state originates> -> <propagation path> -> SYMPTOM: <file:line where it surfaces>`. Your edit targets the CAUSE end.
  Patching the symptom (null check, try/catch, default) instead? Label it `WORKAROUND: <why the root cause is out of reach>`, then Grep the originating symbol repo-wide and paste the hit list of every other place the same bad state flows.
- D4. Iterate on the NARROWEST failing test only (exact node id / -t filter / single file). Full suite only at two points per fix cycle: the baseline and the D8 confirmation — never inside the fix loop. A failed confirmation opens a NEW fix cycle with its own confirmation.
- D5. Never re-run a failing command unchanged. Before any re-run, state one line: the hypothesis and what changed since the last run. Suspected flake: run the test 3x in isolation, paste all 3 outcomes; 3/3 pass -> log `FLAKE: 3/3 pass isolated`; any failure -> the bug is real.
- D6. Failed-attempts ledger: after EVERY failed fix, BEFORE trying again, append: `ATTEMPT n [L<level>]: <what changed> -> <exact observed failure>`. A next attempt differing from a logged one only in surface details is FORBIDDEN -> move up the ESCALATION LADDER.
- D7. Same tool call failed twice with the same error? A third unchanged (or cosmetically varied) attempt is forbidden -> quote the error verbatim, state in one sentence what it implies, then change something structural: different tool, different path, read the config, or ask.
- D8. Fix landed? Two runs, both pasted: (1) the D1 re-run — original command, unmodified — passing; (2) the nearest enclosing suite green (summary line). Suite over ~5 minutes -> changed file's tests plus direct importers' tests; state the subset chosen and why.
- D9. Result contradicts your prediction — in either direction? Do not rationalize it. Prove the executed code is the edited code (temporary marker log line, or printed module path + mtime) and re-run with caches disabled. Only then interpret.
- D10. About to weaken a failing check to get green? Quote the failure, propose the change, wait for approval.

## ESCALATION LADDER (invoked by D6)

The ATTEMPT count sets a floor that never moves down for the same bug; write the L-label into each ledger entry.

- ATTEMPT 1-2: L1 — a different fix under the same hypothesis.
- ATTEMPT 3: L2 required — a NEW hypothesis, formed by re-reading the FULL error output verbatim and the failing code; quote the error line that drives it.
- ATTEMPT 4: L3 required — a pasted minimal reproduction or instrumentation output.
- ATTEMPT 5: L4 required — revert to last-known-good and re-approach.
- ATTEMPT 6 does not exist: L5 — present the full ledger to the user and stop.

## Red flags — your own words are the tripwire

| You are writing/thinking | Do this instead |
|---|---|
| "probably unrelated" | Treat as related: stash your change, rerun, paste the result |
| "pre-existing / not caused by my change" | Prove it: stash your change, run on the clean tree, paste both results |
| "test is probably flaky" | Run the D5 flake procedure (3x isolated, paste all 3) |
| "should work now" | You have not run it. Run it; write `Verified: <command> -> <result line>` |
| "quick fix for now" | Stop. Write the CAUSE line (D3) first |
