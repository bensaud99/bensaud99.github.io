---
name: code-review
description: Use to review code before reporting it done, whether you wrote it or the user did. A checklist ordered by what breaks things first, with a fixed output format.
---

# Code review

Review in this order. Stop at the first level that has blocking problems, fix them, then continue.

## 1. Does it fit together?

- Every import resolves. Every type, function and property that is used exists with the same name and signature.
- Every file mentioned in the Makefile or manifest exists, and every file in the project is actually used.
- Names agree across files: bundle executable, app name, Makefile name, identifiers.
- Resources referenced from code (plists, strings, assets) exist.

## 2. Is it correct?

- Does it do what was asked, including the empty case, the first run and the failure case?
- Off-by-one, optional handling, force unwraps, unchecked array access.
- State: who owns it, who changes it, can two things change it at once?
- Errors: are they handled or at least reported, not swallowed?

## 3. Is it safe?

- Secrets: none in code, logs, defaults or committed files.
- Shell: variables quoted, `set -eu`, no `eval`, no unchecked `rm`, no `curl | sh`.
- File operations: classified with the 🟢 🟡 🔴 tiers; deletes go through `safe-rm.sh`.
- Entitlements and permissions: only what is needed.
- Anything that talks to the network: what does it send, and to whom?

## 4. Does it run on this phone?

- No API newer than iOS 16.4; deployment target 16.0.
- No hardcoded `/var/jb`; paths verified on the device.
- Builds with the toolchain that is installed, not the one you wish was installed.

## 5. Is it clean?

- Small functions and files, one job each. Clear names.
- No dead code, commented-out blocks, debug prints or leftover TODOs.
- Consistent style with the rest of the project.
- Comments explain why, not what.

## Output format

```
Verdict: ship | fix first

Blocking
- path/to/file:LINE: problem. Fix: what to change.

Non-blocking
- path/to/file:LINE: suggestion.

Checked: what you ran (verify.sh, build, tests).
Not checked: what you could not run.
```

Be specific and brief. Quote the line, say what is wrong, say how to fix it. Do not praise filler and do not pad the list: three real problems are worth more than fifteen vague ones.

## Reviewer role (fresh-eyes pass)

When reviewing a change you did not write, adopt the reviewer role: report; do not fix.

1. Read the request the change was meant to satisfy, then the change itself (list of touched files first).
2. Run `scripts/verify.sh <project>` and read every line of its output.
3. Walk the checklist in order: fit together, correct, safe, runs on this phone, clean.
4. Check claims, not impressions. If the author says "builds fine", look for the build output; if there is none, say it is unverified.

Rules:
- Every blocking item has a file, a line, the problem and the fix.
- Separate blocking from non-blocking, and keep non-blocking short.
- Say what you checked and what you could not check.
- If everything is fine, say "ship" and stop. Do not invent findings to look thorough.
