---
name: context-efficiency
description: Use when about to Read a 3rd file over 300 lines, when a search returned more than 50 hits, or when context usage is high. The E1-E17 read-less/read-enough protocol — never trade edit safety for token savings.
---

# Context efficiency (E1-E17)

Governing frame: the unit of cost is the full round trip — a skipped 200-token read that causes one failed edit-debug cycle costs ~10x the read. Every "read less" rule is capped by the "read enough" floors (E2, E4, E14). Never trade edit safety for token savings.

## Read less

- E1. Locate, then read: Grep with -n first; Read only the hit ±40 lines. Full-file Read only when (a) under 250 lines, or (b) you will edit 3+ scattered locations in it (floor: E2). Never Read a file >400 lines without a Grep that failed to localize the target.
- E3. Never re-Read a file or re-run a search unless an E4 event happened since the last one — reuse the earlier result. After a SUCCESSFUL Edit, never Read to confirm it applied (Edit fails loudly); confirm behavior with a command instead.
- E11. Grep returned >50 hits? Do not scroll them or start opening hit files. Re-run with output_mode count or files_with_matches, then narrow. Still >50 relevant hits -> it is a sweep: delegate. Exception: a REFERENCE SWEEP that narrows under 50 stays in main context.
- E12. Never Read package-lock.json, yarn.lock, poetry.lock, dist/, build/, coverage/, *.min.*, *.map, node_modules/, vendor/. Need one fact from them? Grep that file for the specific key.
- E13. Opening a file that neither the task statement nor a search hit identified? First state the one task question it answers. Cannot phrase the question? Do not open it. "Getting context" is not a question.
- E17. A full-file Read justified by E1 on a file >300 lines: at most ONCE per session. Immediately record a 3-6 line structure map (key symbols + line ranges); every later visit is a ranged Read or Grep.

## Read enough (the floors)

- E2. The first edit of a file still requires the code-guardrails C1 — enclosing scope + imports. Editing from a Grep snippet to "save tokens" is the most expensive move available.
- E4. Re-Read the target region before editing if ANY of these happened since your last Read: a formatter/linter/codegen run, any test or build run that may write files, any of git checkout/reset/stash/merge/rebase/pull/apply, a compaction, the user edited, or 20+ intervening tool calls.
- E14. Your next sentence contains "probably / presumably / likely / I assume / should be" about this repo's code? Delete the sentence; run the Grep or Read that answers it. Guessing about verifiable repo facts is never the efficient move.

## Output discipline

- E5. Two or more tool calls where no input depends on another's output? Issue them ALL in one message. Serialize only on a true dependency, and say which output you are waiting for.
- E6. Between tool calls: at most ONE short line, and only to record a finding or decision. Nothing before a call whose purpose is obvious from its parameters.
- E7. Never restate file contents you just read. Reference code as path:line; quote at most 5 lines, only when the exact text IS the finding.
- E10. Command expected to emit >200 lines (builds, installs, full suites, git log, linters): cap it (`git log -n 20`, `| head -50`) or redirect and extract failures — `cmd > build.log 2>&1` then `grep -iE 'error|fail' build.log | head -30`. Never print an entire log into context.
