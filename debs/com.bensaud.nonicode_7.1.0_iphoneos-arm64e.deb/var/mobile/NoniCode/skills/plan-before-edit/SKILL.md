---
name: plan-before-edit
description: Use when a task needs more than 2 file edits, touches more than 1 top-level directory, or before editing a 3rd file with no TASK block posted. The P1-P9 planning checklist plus the TASK block format and the planner-agent role.
---

# Plan before edit (P1-P9)

You are here because the task needs >2 file edits or edits in >1 top-level directory, or you are about to Edit a 3rd file with no TASK block posted, or no other routing row matched.

Walk items in order. Every `P<n>: <content, or N/A — reason>` line must appear in your transcript BEFORE your first Edit.

## Checklist

- P1. Named target: the task names a file, symbol, or stack line? Your FIRST tool call goes there (Grep the symbol or ranged Read around the line). Widen only after that read, only with a stated one-line question the next file answers.
- P2. Premise: write `P2: premise <confirmed|disproved> at <file:line> — <repro output or trace>`.
- P3. Prior art: before writing any helper or feature, Grep 2-3 keyword variants of the concept and check the nearest utils/ lib/ shared/ directory. Write `P3: found <path>` or `P3: none — searched: <terms>`.
- P4. TASK block — post it before your first Edit:
  ```
  GOAL: <one sentence, your own words — not the user's words if the code contradicts them>
  FILES: <exact paths you will change>
  EST: ~<n> changed lines across <n> files
  DONE-WHEN: <a command or observable check>
  CONSTRAINTS: <verbatim every "don't / only / keep / stop" the user stated>
  ```
  Cannot fill FILES yet? Investigate more, then post it. Any later edit to a file not in FILES requires first appending it with a one-line reason.
- P5. Baseline: the repo has a runnable check? Run the narrowest test command covering FILES (single test file or package), else the build, else lint — once — and record `BASELINE: <pass | N failures: names>`. Already red? Report that before starting.
- P6. Size: FILES exceeds 3 files or EST exceeds ~150 lines? Split into numbered steps in dependency order, each ending with a named check. Run and show each check BEFORE the next step.
- P7. Ambiguity: ask the user ONLY when BOTH hold: (a) two reasonable readings produce materially different diffs AND (b) one search of code/tests/docs cannot disambiguate. Otherwise write `ASSUMPTION: <choice> because <evidence>` and proceed.
- P8. Mechanism check: the request names BOTH a fix ("add X") and a symptom ("because Y keeps happening")? Confirm X actually intercepts Y before building. If it does not, report the finding and the alternative in <=5 lines BEFORE implementing.
- P9. Session state: no `.sessions`-tracked STATE.md? Create one per the session-state skill and fill Goal/Now/Next.

## Reference

### A discovered fact contradicts an assumption your plan depends on
STOP before the next step. Write `PLAN CHANGE: assumed <X>; actually <Y> (evidence: <what showed it>) -> revised steps: <...>`. Executing a step whose premise you have personally disproven is forbidden, even if it is already written down.

### The real change is exceeding your TASK block estimate
If actual changed lines or file count passes 2x the EST line (either number), or the work needs a KIND of change not planned: STOP before making that change. Report the discovered scope in <=5 lines with options (full change / minimal safe subset / abort) and wait. Do not silently absorb the expansion.

### You are about to write a helper, class, interface, config option, new file, or install a dependency the task did not name
Concrete tests — apply before adding structure: a helper/class/interface with exactly one caller -> inline it; a config option nobody asked for -> hard-code the current value; a generic used at one type -> make it concrete; a new file under ~30 lines -> merge into an existing file. Dependencies, in order: (1) does an installed dep already cover this? (2) can stdlib or <~30 local lines do it? (3) still needed -> state package, version, one-line justification BEFORE installing.

### Planner agent (read-only role)
When the task is vague or large, adopt the planner role: plan; do not build. Return a plan the main agent can execute and check.
1. Restate the goal in one sentence.
2. Look at what exists: list the project, read the files that matter.
3. List assumptions. If a wrong assumption would be costly or irreversible, turn it into an open question.
4. Break the work into ordered steps. Each step names the files it touches and how to check that it worked.
5. Mark every step that falls in the red tier (destructive/irreversible), and say what backup it needs.
