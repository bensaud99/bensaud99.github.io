---
name: project-delivery
description: Use whenever the user asks for a new project or app. Fixed delivery order: folder structure, every file in full, an installer script, a zip, and (for apps) the Makefile and Entitlements.plist that build a TrollStore-ready .ipa.
---

# Project delivery

The user works from a phone: no repeated copy and paste, no hand-assembling. Deliver so that one command or one tap gives them the whole project.

## Order of delivery

1. **Structure first.** Send the folder tree in a code block, one line of purpose per file.
2. **Every file, in full.** One block per file, with its relative path as a heading, in a fenced block tagged with the language, so it can be copied or saved directly. No "...rest unchanged" and no abbreviated files.
3. **Installer script.** A single `.sh` that recreates the folder, all sub-folders, all files and all their contents. Generate it with `scripts/pack-project.sh`; do not retype it by hand.
4. **Zip.** The same project as a `.zip` (also produced by `pack-project.sh`) for Filza.
5. **Build step.** For an app: `cd <project> && make`, and where the `.ipa` will appear.

When the platform can send files, send each file and the installer and zip as files too.

## Content rules

- An app that will be installed with TrollStore always contains `Makefile`, `Entitlements.plist`, `Resources/Info.plist` and `Sources/` (see `skills/trollstore-ipa`).
- The interface is Arabic, right-to-left, SwiftUI, with a polished look and fitting emojis (see `skills/swiftui-arabic-app`).
- Target iOS 16.0 and use nothing newer than 16.4.
- Clean, consistent, tidy: small files, no dead code, one naming scheme.

## Before sending

1. Run `scripts/verify.sh <project>` and fix everything it reports.
2. Run the consistency check from `CLAUDE.md` section 5 by hand: imports, names, signatures, Makefile file list, resources.
3. Generate the installer and zip, then test them:

```sh
scripts/pack-project.sh <project> -o <outdir>
mkdir -p /tmp/kwwk-check && bash <outdir>/<name>-install.sh /tmp/kwwk-check/<name>
diff -r <project> /tmp/kwwk-check/<name> && echo "installer matches"
unzip -t <outdir>/<name>.zip
```

4. Say plainly what you could not test (usually: running the app on the device).

## Final message

Short: where the files are, the one-line install command, the one-line build command, and anything the user must decide or check.
