---
name: trollstore-ipa
description: Use when producing a signed .ipa that the user installs with TrollStore. Covers the required files, building with Theos, the manual ldid fallback, entitlements, verification and the usual pitfalls.
---

# Building an .ipa for TrollStore

TrollStore installs an `.ipa` as it is and keeps the entitlements embedded in the binary, so the build must (1) produce a valid app bundle and (2) sign the main binary with the right entitlements using `ldid`.

## 1. Required files

```
MyApp/
├── Makefile
├── Entitlements.plist
├── Resources/
│   └── Info.plist
└── Sources/
    └── *.swift
```

Start from `templates/` in the kit, then rename everything consistently. These three names must be identical: `APPLICATION_NAME` in the Makefile, `CFBundleExecutable` in `Info.plist`, and the `.app` folder. A mismatch is the most common reason an `.ipa` installs but never opens.

## 2. Build with Theos

```sh
export THEOS="${THEOS:-/var/mobile/theos}"
cd MyApp
make clean
make package            # the template's after-stage step writes packages/MyApp.ipa
ls -l packages/
```

Do not set `THEOS_PACKAGE_SCHEME` for an app that is going to be an `.ipa`: the app has to sit under `Applications/` in the staging folder, not under a jailbreak prefix.

If `make` fails, read the first error, not the last. Fix, then `make clean` and try again.

## 3. Manual fallback (when the Theos route will not build)

```sh
APP=MyApp
rm -rf Payload && mkdir -p Payload/$APP.app
cp <built-binary> Payload/$APP.app/$APP
cp Resources/Info.plist Payload/$APP.app/Info.plist
chmod 755 Payload/$APP.app/$APP
ldid -SEntitlements.plist Payload/$APP.app/$APP     # no space after -S
zip -qry $APP.ipa Payload
```

## 4. Entitlements

Keep the set minimal and add only what the app needs. The template contains:

| Key | Why |
|---|---|
| `platform-application` | runs as a platform app |
| `com.apple.private.security.no-sandbox` | access to files outside the app container |
| `com.apple.private.security.no-container` | no container redirection |
| `get-task-allow` | debugging |

Drop the two `private.security` keys for an app that never needs to leave its own folder. Do not add entitlements you cannot explain: an unverified one can make the app die at launch. Ask the user before adding more.

## 5. Verify before you hand it over

```sh
unzip -l packages/MyApp.ipa | head -20             # only Payload/, exactly one .app
ldid -e Payload/MyApp.app/MyApp | head -20         # embedded entitlements are there
scripts/verify.sh .                                # plist lint, names, API checks
```

Also check:

- `CFBundleExecutable` matches the binary name.
- `MinimumOSVersion` is 16.0 or lower (the phone is on 16.4.1).
- `CFBundleIdentifier` is unique and has no spaces.
- The binary is arm64 (`lipo -info` or `otool -hv`, whichever exists).
- Executable bit is set on the main binary.

## 6. Install

The user installs it: open the `.ipa` with TrollStore (Filza, then Open with TrollStore, or the Share sheet). Give them the full path of the file. After installing, if the icon does not show, they can refresh with `uicache -a` (🟡; mention it, do not run it silently).

## Pitfalls

- Missing `Info.plist` keys: `CFBundleExecutable`, `CFBundleIdentifier`, `CFBundlePackageType` (APPL), `MinimumOSVersion`.
- A zip with an extra top-level folder: the archive root must be `Payload/`.
- Invalid XML in `Entitlements.plist`: lint it first.
- SwiftUI `@main` in a single file needs `-parse-as-library`.
- Using an API newer than iOS 16.4: it compiles on a newer SDK and then crashes on the phone.
