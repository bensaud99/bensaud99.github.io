---
name: swiftui-arabic-app
description: Use when writing any SwiftUI app or screen for this user, and for any Arabic or right-to-left UI. Gives the project layout, RTL setup, the iOS 16.4 API limits, and the quality bar for the interface.
---

# SwiftUI apps with an Arabic interface

The phone runs iOS 16.4.1. Everything in the UI is Arabic and right-to-left unless the user says otherwise.

## Project layout

```
Sources/
├── App/            MyAppApp.swift (the @main entry), RootView.swift
├── Models/         plain structs, Codable
├── ViewModels/     ObservableObject classes
├── Views/          one screen per file
├── Components/     small reusable views
└── Support/        Strings.swift (all Arabic text), Theme.swift (colours, spacing, fonts)
```

The Makefile collects sources with `$(shell find Sources -name '*.swift')`, so new files are picked up without editing it.

## RTL and language

```swift
@main
struct MyAppApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
        }
    }
}
```

- `Info.plist`: `CFBundleDevelopmentRegion` = `ar`, `CFBundleLocalizations` = `ar`, `en`.
- Use `.leading` and `.trailing`, never `.left` and `.right`. Icons that show direction (back arrows, chevrons) flip by themselves when they are SF Symbols; custom images need `.flipsForRightToLeftLayoutDirection(true)`.
- Digits: choose on purpose. `Locale(identifier: "ar@numbers=latn")` gives 0-9, `ar@numbers=arab` gives ٠-٩. Ask the user if they have not said.
- Keep every user-visible string in `Support/Strings.swift`.

## APIs that do NOT exist on iOS 16.4: do not use them

| Do not use (iOS 17+ / Swift 5.9 tooling) | Use instead |
|---|---|
| `@Observable` macro | `ObservableObject` + `@Published` + `@StateObject` |
| SwiftData (`@Model`, `@Query`) | Codable + `UserDefaults` or JSON in Documents |
| `ContentUnavailableView` | a small custom empty-state view |
| `.sensoryFeedback` | `UIImpactFeedbackGenerator` |
| `.onChange(of:) { old, new in }` (two parameters) | `.onChange(of:) { new in }` |
| `.scrollTargetBehavior`, `.scrollPosition` | plain `ScrollView` + `ScrollViewReader` |
| `#Preview` macro | skip previews, or a `PreviewProvider` struct |
| `NavigationView` for new code | `NavigationStack` (iOS 16) |

Available and good: `NavigationStack`, `NavigationSplitView`, `Grid`, `ViewThatFits`, `Gauge`, Swift Charts, `.presentationDetents`, `.scrollContentBackground`, `.scrollIndicators`, `.scrollDismissesKeyboard`, `.searchable`, `.refreshable`, `.swipeActions`, `@AppStorage`, `@FocusState`.

If you are not sure that an API is available in iOS 16.4, treat it as unavailable and use the safer alternative.

## State and structure

- One `ObservableObject` per screen or feature. The view owns it with `@StateObject`; children get it as `@ObservedObject` or `@EnvironmentObject`.
- Views stay small: if a `body` is longer than about 60 lines, split it into components.
- No force unwraps and no `try!` outside of tests.
- Persist with `Codable` JSON in the Documents folder or with `@AppStorage`. Handle the first launch, when nothing is saved yet.

## Interface quality bar

- A visible theme: one accent colour, system backgrounds (so dark mode works), consistent corner radius and spacing from `Theme.swift`.
- SF Symbols for icons, and fitting emojis in titles or empty states (✅ 📁 ⚙️). Not on every line.
- Large-title navigation, grouped lists or cards, clear empty and error states, haptic feedback on key actions.
- Dynamic Type works: use text styles (`.title2`, `.body`), not fixed sizes.
- Every screen reachable, every button labelled in Arabic, no placeholder text left behind.

## Before you say it is done

1. Every file referenced exists, every type used is defined.
2. `scripts/verify.sh .` is clean (it warns about iOS 17+ APIs).
3. Build with `make`, read the output.
4. Tell the user what you could not test on the device.
