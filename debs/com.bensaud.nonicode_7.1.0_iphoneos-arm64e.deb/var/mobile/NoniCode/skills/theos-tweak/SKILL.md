---
name: theos-tweak
description: Use when creating, building, packaging or installing a Theos tweak or deb on the RootHide jailbreak. Covers environment checks, the package scheme, project layout, narrow injection filters, install and rollback.
---

# Theos tweaks on RootHide

Theos lives at `/var/mobile/theos` on this device. RootHide differs from a normal rootful or rootless jailbreak, so check the facts on the device before building anything.

## 1. Check the environment

```sh
scripts/env-check.sh
export THEOS="${THEOS:-/var/mobile/theos}"
ls "$THEOS/makefiles" | head
grep -rIl roothide "$THEOS" 2>/dev/null | head      # is this a RootHide-aware Theos?
command -v jbroot                                    # path translation helper, if present
```

Decide the packaging scheme from what you find:

- RootHide-aware Theos found: set `THEOS_PACKAGE_SCHEME = roothide` in the Makefile.
- Not found: stop and tell the user. A deb built for another scheme can install files where RootHide will not look for them. Ask whether to install the RootHide-aware Theos fork first.

Never hardcode `/var/jb` in code or Makefiles. If the RootHide headers are available (`find "$THEOS" -name roothide.h`), use their path helpers for any path inside the jailbreak root.

## 2. Project layout

```
MyTweak/
├── Makefile
├── control
├── MyTweak.plist      ← injection filter
└── Tweak.x
```

Makefile:

```make
TARGET := iphone:clang:latest:14.0
ARCHS = arm64 arm64e
THEOS_PACKAGE_SCHEME = roothide
INSTALL_TARGET_PROCESSES = SpringBoard

include $(THEOS)/makefiles/common.mk

TWEAK_NAME = MyTweak
MyTweak_FILES = Tweak.x
MyTweak_CFLAGS = -fobjc-arc

include $(THEOS_MAKE_PATH)/tweak.mk
```

Change `INSTALL_TARGET_PROCESSES` to the process you are actually hooking, or remove the line so nothing is killed automatically.

`control` (one blank line at the end):

```
Package: com.example.mytweak
Name: MyTweak
Version: 0.0.1
Architecture: iphoneos-arm64
Description: What it does in one line
Maintainer: user
Author: user
Section: Tweaks
Depends: mobilesubstrate
```

`MyTweak.plist`, the filter. Keep it as narrow as possible:

```xml
{ Filter = { Bundles = ( "com.example.targetapp" ); }; }
```

## 3. Rules for the code

- Hook the smallest surface that does the job. No filter on `com.apple.UIKit` or `com.apple.Foundation`. No `SpringBoard` or `launchd` hooks unless the user asked for that explicitly (🔴).
- Always call `%orig` unless you really replace the behaviour.
- Nil-check everything that comes from a hooked method. A crash in `SpringBoard` is a respring loop.
- Put setup in `%ctor`, and keep it cheap.

## 4. Build, inspect, install

```sh
make clean package
dpkg -I packages/*.deb          # control data
dpkg -c packages/*.deb          # file list: paths must match the RootHide scheme
grep -rn "/var/jb" . || true    # should print nothing
```

Installing:

- `dpkg -i packages/<file>.deb` is 🟡 for an app-only tweak and 🔴 for anything that injects into `SpringBoard`, `launchd` or system daemons.
- A respring or `sbreload` is 🔴. Ask first, and say what will be interrupted.
- Before testing a risky tweak, ask the user how they disable tweak injection if the phone misbehaves, and write the answer in your report.

## 5. Frameworks injection (when Theos cannot be used)

Some targets are plain app bundles, not tweak-injectable processes. Injecting a dylib into an app's main binary needs an `LC_LOAD_DYLIB` command added, which `ldid` cannot do (it only signs). Use the bundled tool:

```sh
scripts/bin/insert_dylib --inplace --weak --no-strip-codesig \
    "@rpath/MyLib.dylib" MyApp.app/MyApp
ldid -S MyApp.app/MyApp          # re-sign after injection
```

Flags that matter:

- `--weak` — the app still launches if the dylib is missing (use this for anything shipped to a device you may not control).
- `--no-strip-codesig` — keep the existing signature block so `ldid` has something to overwrite. Verify it worked with `otool -L MyApp.app/MyApp | grep MyLib`.
- `--inplace` — modify the binary directly. Without `--inplace`, the new path argument is required.

**Order matters:** inject first, sign second. Signing before injection invalidates the signature and the app will not launch. Copy the dylib into `MyApp.app/Frameworks/` and `chmod 755` it before injecting.

`scripts/bin/insert_dylib` is the only such tool on this device — it is not in `PATH` and no package owns it. Do not delete it.

## 6. Rollback

`dpkg -r <package-id>` needs a yes (🔴). Keep the previous deb and the backup path from `scripts/backup.sh` in your report.

## Common failures

| Symptom | Likely cause |
|---|---|
| `Cannot find THEOS` | `export THEOS=/var/mobile/theos` |
| Files install but the tweak never loads | wrong package scheme, or the filter plist name does not match `TWEAK_NAME` |
| Build error about SDK | `TARGET` points at an SDK that is not in `$THEOS/sdks`; list the folder and use one that exists |
| Respring loop after install | bad hook in `SpringBoard`; disable injection, remove the package, fix, rebuild |
