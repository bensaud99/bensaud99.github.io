---
name: dangerous-command-guard
description: Use before running any destructive shell command — recursive delete, system/jailbreak path write, package removal, reboot/respring, force push, dd to device, or piping a download into a shell. Classifies the command and says when to ask the user first.
---

# Dangerous command guard

Before running a command in the red tier below, stop and ask the user. Announce the reason, name the exact path, offer the backup path.

## Command classifier

All patterns are matched case-insensitively against the command string. If any matches, this is red-tier: ask first.

- **Recursive delete** — `rm -r`, `rm -rf`, `rm --recursive`: use a trash-based safe-rm instead of `rm -r`.
- **Modifies a system or jailbreak path** — any `rm|mv|cp|ln|tee|dd|chmod|chown|touch|install|rsync` or `sed -i` where the target matches `/System`, `/usr/`, `/private/preboot`, `.jbroot`, or `/Library/LaunchDaemons`.
- **Redirects output into a system or jailbreak path** — `>` or `>>` into any of the paths above.
- **Recursive permission or owner change** — `chmod -R`, `chown -R`, `chgrp -R`.
- **Writes to a block device** — `dd ... of=/dev/...`, or `> /dev/rdisk*`, `> /dev/disk*`, `> /dev/sd*`.
- **Formats a filesystem** — `mkfs*`, `newfs*`.
- **Removes or purges a package** — `dpkg -r`, `dpkg -P`, `dpkg --remove`, `dpkg --purge`, `apt remove`, `apt purge`, `apt autoremove`.
- **Reboots or restarts the device** — `reboot`, `halt`, `shutdown`, `ldrestart`, `userspace reboot`, `launchctl reboot`.
- **Respring or kills a system process** — `sbreload`, or `killall SpringBoard|backboardd|launchd|mediaserverd|cfprefsd`.
- **Changes launch daemons** — `launchctl unload|remove|bootout`.
- **Pipes a download into a shell** — `curl ... | sh`, `wget ... | sh`, optionally via `sudo`.
- **Force push** — `git push --force`, `git push --force-with-lease`, `git push -f`.
- **Destroys uncommitted work** — `git reset --hard`, `git clean -f`, `git clean -d`.

## What to do when matched

1. Name the exact absolute paths the command touches (`ls -ld <path>`).
2. Classify: inside the project = safe; outside the project = ask; system/jailbreak path or recursive delete = always ask.
3. Back up with `scripts/backup.sh <paths>` first, keep the archive path, report it to the user.
4. Only after explicit user approval, run the command.

## Backup + restore

```sh
scripts/backup.sh /path/one /path/two        # tar.gz in ./backups
scripts/safe-rm.sh /path/to/thing            # move to ./trash/<batch>
scripts/safe-rm.sh --list                    # show batches
scripts/safe-rm.sh --restore <batch>         # put everything back
tar -xzf <archive> -C /                      # restore from a backup archive
```

## Habits that prevent disasters

- Print `pwd` before any relative delete or move.
- Use `${VAR:?}` for variables inside delete paths, so an empty variable aborts instead of becoming `/`.
- Run `find ... -print` and read it before adding `-delete` or `-exec`.
- Never run `chmod -R` or `chown -R` on a broad path. Name the exact folder.
- Do not hand-edit a running app's preferences plist: `cfprefsd` caches it and can overwrite your change. Stop the app first, or use `defaults`.
- Trailing slashes matter to `rsync` and `cp`. Check the result.

## Never touch without a human

`/System`, `/usr`, `/private/preboot`, the jailbreak root (`/var/containers/Bundle/Application/.jbroot-*`), `/Library/LaunchDaemons`, and other apps' data containers. Do not look for a way around this.
