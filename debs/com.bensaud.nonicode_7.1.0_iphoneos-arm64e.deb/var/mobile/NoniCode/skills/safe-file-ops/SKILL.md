---
name: safe-file-ops
description: Use before deleting, moving, overwriting or bulk-editing files, and when restoring something that was removed. Gives the backup, safe-rm, verify, restore routine for a phone where one wrong path can cause a bootloop.
---

# Safe file operations

## When to use

Any time a command would remove, overwrite, rename or mass-modify files that are not brand-new files inside the current project.

## Routine

1. **Name the target.** Print the exact absolute paths you are about to touch (`ls -ld <path>`). Expand globs first (`echo <glob>`) and read the result. A glob that matches more than you expected is the classic way to lose data.
2. **Classify it.** Inside the project is green. Outside the project but inside the workspace home is yellow. Anything else, and any recursive delete, is red (see `CLAUDE.md`).
3. **Guard it.** For red-tier work read the `dangerous-command-guard` skill and follow its classifier — it names every red-tier pattern and when to ask the user first.
4. **Back it up.** `scripts/backup.sh <paths>` prints the archive path. Keep that path so you can report it.
5. **Do it the safe way.**
   - delete: `scripts/safe-rm.sh <path>...` (moves to the trash, never `rm -rf`)
   - overwrite: write `<file>.new`, check it, then `mv <file>.new <file>`
   - copy or move: `cp -n` and `mv -n`, so nothing is replaced silently
6. **Verify.** List the result and compare it with what you intended.
7. **Report the way back.** Give the user the backup archive or trash batch name and the exact restore command.

## Commands

```sh
scripts/backup.sh /path/one /path/two          # tar.gz in ./backups
scripts/safe-rm.sh /path/to/thing              # move to ./trash/<batch>
scripts/safe-rm.sh --list                      # show batches
scripts/safe-rm.sh --restore <batch>           # put everything back
tar -xzf <archive> -C /                        # restore from a backup archive
```

A permanent purge (`scripts/safe-rm.sh --purge <batch>`) needs the user's explicit yes.

## Habits that prevent disasters

- Print `pwd` before any relative delete or move.
- Use `${VAR:?}` for variables inside delete paths, so an empty variable aborts instead of becoming `/`.
- Run `find ... -print` and read it before you add `-delete` or `-exec`.
- Never run `chmod -R` or `chown -R` on a broad path. Name the exact folder.
- Do not hand-edit a preferences plist of a running app: `cfprefsd` caches it and can overwrite your change. Stop the app first, or use `defaults`.
- Trailing slashes matter to `rsync` and `cp`. Check the result.

## Never touch without a human

`/System`, `/usr`, `/private/preboot`, the jailbreak root (`/var/containers/Bundle/Application/.jbroot-*`), `/Library/LaunchDaemons`, and other apps' data containers. `safe-rm.sh` refuses the obvious ones; do not look for a way around it.

## Worked example

User: "delete the old project folder".

```sh
ls -ld ~/old-project                         # confirm it is what the user means
du -sh ~/old-project                         # size, to report
scripts/backup.sh ~/old-project              # optional but cheap
scripts/safe-rm.sh ~/old-project             # moved to trash, batch name printed
```

Report the batch name and the exact `scripts/safe-rm.sh --restore <batch>` command.
