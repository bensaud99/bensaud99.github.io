---
name: verify-before-done
description: Use before writing "done", "fixed", "works", "passing", "complete", or "resolved", and before any git commit or handover. The V1-V12 echo protocol: every claim needs a quoted command output from a tool result earlier in this turn.
---

# Verify before done (V1-V12 echo protocol)

You are here because you are about to write "done", "fixed", "works", "passing", "complete", "resolved", or "ready", or to run git commit / hand over a change.

**Echo protocol:** walk this checklist by writing one line per item — `V<n>: PASS — <command> -> <last output line>` | `V<n>: FAIL — <command> -> <failing line>` | `V<n>: N/A — <one-line reason naming the absent precondition>`. A PASS without a quoted output line counts as FAIL; an N/A without a reason counts as FAIL. Every quoted output line must appear verbatim in a tool result earlier in THIS turn — quote it, never retype it. Do not write "done", "fixed", or "works", or run git commit, while any line reads FAIL.

## Checklist

- V1. Fresh evidence: your V1 line quotes the PRIMARY verification command run AFTER the last edit and its output line. Output from before the last edit proves nothing.
- V2. Test summary line quoted verbatim (e.g. "12 passed, 1 skipped in 3.2s"). "0 tests", "no tests found", "collected 0 items" is a FAIL of verification, not a pass. Every skipped/xfailed explained or investigated. No test runner? Write `V2: N/A — no test suite (<the Glob you ran> -> 0 hits)` and V4's behavior probe becomes mandatory.
- V3. Failure-token scan on any verification output over ~30 lines: grep it case-insensitively for `error|fail|warn|skip|traceback|exception`; quote up to the first 10 hits with a one-word disposition each (benign/real), or state "failure-token scan: 0 hits". More than 10 hits -> the run is not clean; stop and investigate. Output was piped? bash: print `${PIPESTATUS[0]}`.
- V4. "It compiles" is gate 0, never completion evidence. After build/typecheck passes, also run the tests or a behavior probe for the changed code path and quote its result line.
- V5. Verifying via a binary, bundle, or installed CLI? It was rebuilt in THIS turn, or you ran from source or an editable install.
- V6. Monorepo/multi-package: the passing run's output names at least one test file that exercises your changed module — quote that line.
- V7. Multi-part request: quote the original request verbatim; mark every distinct deliverable VERIFIED (command) / EDITED-UNVERIFIED / NOT-DONE. Reporting NOT-DONE is acceptable; silently dropping it is not.
- V8. Scope audit: run `git diff --stat HEAD`; give a one-line justification per changed file tracing it to the GOAL or a logged DETOUR. Unjustifiable file -> revert it. An empty stat after edits is itself a FAIL.
- V9. Open items: classify every entry in the session-state open-items list as done-with-evidence or explicitly-reported-undone.
- V10. You changed a test expectation or ran snapshot-update during this task? Paste the old-vs-new quote and justification.
- V11. Service/endpoint change: completion evidence is a pasted request + response exercising the changed route, including one case the change was supposed to alter. "Listening on :3000" is never evidence.
- V12. Triviality waives nothing — one-liners have the highest surprise rate per line. Sole exemption: changes touching only comments/docs, stated as "comment/doc-only change; behavior verification not applicable". Whitespace edits in indentation-significant files are NOT exempt.

## Verdict format

```
Verdict: ship | fix first

V1: PASS — <cmd> -> <output line>
V2: PASS — <summary line> / N/A — <reason>
...
V12: PASS — <evidence>

Verified: <commands run, results>
Not verified: <what you could not test and why>
```

Be specific. Every clause traceable to a tool result in the transcript. A bare "all good" is not a verdict.
