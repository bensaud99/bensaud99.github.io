---
name: performance-benchmark
description: Measure before claiming speed
---

# Measure before claiming speed

Compare identical provider/model/task/temperature, device state and terminal. Record p50/p95 end-to-end latency, TTFT, memory, API bytes and tool count. Do not compare a local response with remote inference or claim model intelligence was improved by documentation alone.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
