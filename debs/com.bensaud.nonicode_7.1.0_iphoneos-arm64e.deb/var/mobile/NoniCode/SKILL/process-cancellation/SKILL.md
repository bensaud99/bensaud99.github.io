---
name: process-cancellation
description: Bounded subprocesses
---

# Bounded subprocesses

Run tests/test_native.c with ASan and UBSan on host. Check success, failed spawn, exit status, missing stdin, huge output, timeout and cancellation. Ensure Esc joins the worker rather than detaching it. Process groups do not contain deliberately detached daemons; never call this an OS sandbox.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
