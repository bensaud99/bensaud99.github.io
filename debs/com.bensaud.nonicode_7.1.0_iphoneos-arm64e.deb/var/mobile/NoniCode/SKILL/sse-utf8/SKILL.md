---
name: sse-utf8
description: Streaming parser
---

# Streaming parser

Keep bytes across packets; decode only a complete event. Test Arabic and emoji with every input split, CRLF, comments, multi-line data, final unterminated event, malformed and oversized input. Reject HTTP errors before executing text as tool calls.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
