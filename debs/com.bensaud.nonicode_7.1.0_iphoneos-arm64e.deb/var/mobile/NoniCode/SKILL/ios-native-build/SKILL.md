---
name: ios-native-build
description: Native iOS build
---

# Native iOS build

Confirm SDK availability, deployment target <=16.4.1 and arm64 slice. Build Objective-C with ARC and blocks against iOS Foundation. Use posix_spawn, not NSTask/Process. Inspect LC_BUILD_VERSION and code signature, then install through dpkg. Refuse silent signing fallback.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
