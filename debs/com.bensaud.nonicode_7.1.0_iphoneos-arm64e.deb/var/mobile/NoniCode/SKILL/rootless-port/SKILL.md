---
name: rootless-port
description: Rootless layout
---

# Rootless layout

Use the same arm64 core and a separate launcher compiled for /var/jb. Package all immutable files beneath var/jb. Verify iphoneos-arm64 metadata. Do not use a RootHide .deb on a rootless bootstrap or vice versa.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
