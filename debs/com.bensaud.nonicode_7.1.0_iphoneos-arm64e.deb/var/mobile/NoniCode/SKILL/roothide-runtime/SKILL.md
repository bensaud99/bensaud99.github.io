---
name: roothide-runtime
description: Physical paths and vroot
---

# Physical paths and vroot

Read AGENTS.md runtime section. Run native doctor. Confirm dpkg architecture on device. Use the installed launcher and check both bootstrap shell and rootfs() conversion. Never scan or copy credentials across all app containers. Test installed launch from sh, zsh and fish; a host compile does not establish entitlement enforcement.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
