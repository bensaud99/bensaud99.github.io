---
name: trollstore-ipa
description: TrollStore app scaffold
---

# TrollStore app scaffold

TrollStore is an IPA installer, not this CLI package or a jailbreak shell. A generated SwiftUI scaffold requires a working Swift compiler/SDK. Sign the executable inside .app, not the folder. Avoid banned debugger/JIT/library-validation entitlements. Test the IPA in TrollStore manually; do not promise tweak injection without a jailbreak.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
