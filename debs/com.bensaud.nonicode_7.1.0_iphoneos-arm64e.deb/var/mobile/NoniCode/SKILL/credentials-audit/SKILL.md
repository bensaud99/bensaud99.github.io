---
name: credentials-audit
description: Credentials and private storage
---

# Credentials and private storage

Inspect file modes and ownership without printing contents. Auth/session dirs 0700; files 0600. Test malformed JSON and symlinks with disposable fixtures. Network endpoint changes clear keys. Never claim plaintext private files are encrypted.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
