---
name: provider-contract
description: Model-provider contract
---

# Model-provider contract

Enter a real model ID from the chosen provider. Anthropic Messages and OpenAI-compatible Chat Completions are distinct request formats. OpenAI Responses API and provider subscription OAuth are not implemented. Do not fake support by changing client IDs or scraping tokens from another CLI.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
