---
name: review-plan
description: Plan and verify changes
---

# Plan and verify changes

Write a short concrete plan, then use scoped reads. Separate blockers from recommendations. Review authorization boundaries, native paths and failed I/O before adding features. Prefer a tested small patch over unsupported plugin counts.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
