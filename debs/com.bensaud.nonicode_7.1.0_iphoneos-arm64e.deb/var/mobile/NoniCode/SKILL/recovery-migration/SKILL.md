---
name: recovery-migration
description: Preserve user state
---

# Preserve user state

Back up only to a private local directory under the user account. Never include keys in shared bug reports. Installer leaves existing files intact and ships new defaults in usr/share/nonicode/workspace. Move legacy symlinks aside intentionally; postinst refuses them. A version downgrade needs compatible state format verification.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
