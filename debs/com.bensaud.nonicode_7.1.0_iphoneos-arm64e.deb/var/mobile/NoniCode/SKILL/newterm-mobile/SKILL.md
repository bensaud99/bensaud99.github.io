---
name: newterm-mobile
description: Mobile terminal regression
---

# Mobile terminal regression

Test NewTerm3 on the actual iPhone: Arabic input, emoji backspace, resizing, scroll hold, live steering, Esc, Ctrl-C, EOF and SIGTERM. Confirm original termios/cursor restore. Avoid continuous repaint while the user scrolls. Unicode display width and bidirectional rendering remain terminal-dependent.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
