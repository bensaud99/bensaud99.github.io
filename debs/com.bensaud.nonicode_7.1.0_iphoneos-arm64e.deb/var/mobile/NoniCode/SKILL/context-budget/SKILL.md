---
name: context-budget
description: Keep model context small
---

# Keep model context small

Load unified policy and the skill index, then exactly the relevant skill. Keep reference corpus inert. Use read offsets, focused grep and at most four small attachments. State that local context percentage is character-based. /compact discards old context, so record important facts before invoking it.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
