---
name: safe-network
description: Bounded authenticated HTTP
---

# Bounded authenticated HTTP

HTTPS only except exact loopback HTTP. No credential-bearing redirects. Use ephemeral sessions, bounded responses and finite resource deadlines. Rate limit errors are surfaced; do not replay a tool-producing request automatically. API inference is the only expected network activity unless a fetch is separately approved.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
