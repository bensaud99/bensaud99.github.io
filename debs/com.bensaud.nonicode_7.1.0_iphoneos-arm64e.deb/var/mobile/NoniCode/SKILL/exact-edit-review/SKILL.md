---
name: exact-edit-review
description: Exact edits and patches
---

# Exact edits and patches

Read the target first. Require a unique old-text match. Apply multi-edit to an in-memory copy; write once after all edits validate. For unified diffs validate positions and hunk counts. Show errors for unsupported CRLF or no-newline markers; do not silently apply partial hunks.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
