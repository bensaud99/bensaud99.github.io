---
name: git-workflow
description: Scoped version control
---

# Scoped version control

Inspect status and diff before editing, staging or committing. Disable external diff/textconv/fsmonitor for a diagnostic diff. Never auto-push, overwrite local changes, reset --hard or clean directories. A commit still requires approval through the shell gate.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
