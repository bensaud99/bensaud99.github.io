---
name: package-review
description: Review a staged .deb
---

# Review a staged .deb

Use exact versioned outputs. Inspect control architecture, package tree, two Mach-O signatures, deployment target and library paths. Confirm no noni_auth.json, .sessions or private-key material. Stage only immutable repo data, never the live phone workspace. Read diff and binary strings before publishing.

## Completion evidence
State the exact files changed and checks actually run. Distinguish host validation from device behavior. Stop on a failed safety or signing check.
