#!/usr/bin/env bash
# backup.sh - archive paths into $KWWK_HOME/backups before a risky change.
# Usage: backup.sh <path>...      prints the archive path on stdout
# Restore: tar -xzf <archive> -C /
set -eu

KWWK_HOME="${KWWK_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"
DEST="$KWWK_HOME/backups"

usage() { sed -n '2,4p' "$0" | sed 's/^# \{0,1\}//'; }

if [ $# -lt 1 ]; then usage >&2; exit 64; fi
case "$1" in -h|--help) usage; exit 0 ;; esac
command -v tar >/dev/null 2>&1 || { echo "backup: tar not found" >&2; exit 1; }

abspath() {
  local d b
  if [ "$1" = "/" ]; then printf '/\n'; return 0; fi
  d=$(dirname -- "$1"); b=$(basename -- "$1")
  d=$(cd "$d" 2>/dev/null && pwd -P) || return 1
  if [ "$d" = "/" ]; then printf '/%s\n' "$b"; else printf '%s/%s\n' "$d" "$b"; fi
}

rels=()
for p in "$@"; do
  if [ ! -e "$p" ] && [ ! -L "$p" ]; then echo "backup: not found: $p" >&2; exit 1; fi
  a=$(abspath "$p") || { echo "backup: cannot resolve: $p" >&2; exit 1; }
  case "$a" in
    /|//) echo "backup: refusing to archive /" >&2; exit 1 ;;
  esac
  rels+=("${a#/}")
done

mkdir -p "$DEST"
stamp=$(date +%Y%m%d-%H%M%S)
label=$(printf '%s' "$(basename -- "$1")" | tr -c 'A-Za-z0-9._-' '_')
out="$DEST/$label-$stamp-$$.tar.gz"
tar -czf "$out" -C / "${rels[@]}"
tar -tzf "$out" >/dev/null
printf '%s\n' "$out"
echo "backup: $(du -h "$out" | cut -f1), restore with: tar -xzf '$out' -C /" >&2
