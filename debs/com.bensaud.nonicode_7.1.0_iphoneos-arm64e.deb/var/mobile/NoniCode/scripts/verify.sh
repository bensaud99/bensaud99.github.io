#!/usr/bin/env bash
# verify.sh - pre-delivery checks for a project folder.
# Usage: verify.sh [project-dir]     (default: current directory)
# Exit:  0 = no errors (warnings are allowed), 1 = errors found, 64 = usage
set -u

usage() { sed -n '2,4p' "$0" | sed 's/^# \{0,1\}//'; }

dir="${1:-.}"
case "$dir" in -h|--help) usage; exit 0 ;; esac
[ -d "$dir" ] || { echo "verify: not a directory: $dir" >&2; exit 64; }
dir=$(cd "$dir" && pwd -P)

errors=0
warns=0
ok()   { printf '  ✅ %s\n' "$*"; }
warn() { printf '  ⚠️  %s\n' "$*"; warns=$((warns + 1)); }
fail() { printf '  ❌ %s\n' "$*"; errors=$((errors + 1)); }
have() { command -v "$1" >/dev/null 2>&1; }

# files in the project, without build output and VCS folders
files() {
  find "$dir" \( -name .git -o -name .theos -o -name packages -o -name trash -o -name backups \) -prune \
    -o -type f -name "$1" -print | LC_ALL=C sort
}

plist_str() { # file key -> string value (first match)
  tr '\n' ' ' < "$1" | sed -n "s/.*<key>$2<\/key>[[:space:]]*<string>\([^<]*\)<\/string>.*/\1/p"
}

printf '== verify: %s ==\n' "$dir"

# 1. shell scripts
echo "-- shell scripts"
n=0
while IFS= read -r f; do
  [ -n "$f" ] || continue
  n=$((n + 1))
  rel="${f#"$dir"/}"
  if bash -n "$f" 2>/dev/null; then
    if [ -x "$f" ]; then ok "$rel"; else warn "$rel: syntax ok but not executable (chmod +x)"; fi
  else
    fail "$rel: syntax error (run: bash -n $rel)"
  fi
done <<EOF_SH
$(files '*.sh')
EOF_SH
[ "$n" -gt 0 ] || echo "  (none)"

# 2. plists
echo "-- plists"
n=0
while IFS= read -r f; do
  [ -n "$f" ] || continue
  n=$((n + 1))
  rel="${f#"$dir"/}"
  if have plutil; then
    if plutil -lint "$f" >/dev/null 2>&1; then ok "$rel"; else fail "$rel: invalid plist (plutil -lint)"; fi
  elif grep -q '<?xml' "$f" 2>/dev/null; then
    if have python3; then
      if python3 -c 'import plistlib,sys; plistlib.load(open(sys.argv[1],"rb"))' "$f" >/dev/null 2>&1; then
        ok "$rel"
      else
        fail "$rel: invalid plist"
      fi
    elif have xmllint; then
      if xmllint --noout "$f" >/dev/null 2>&1; then ok "$rel"; else fail "$rel: invalid XML"; fi
    else
      warn "$rel: no plist linter available"
    fi
  else
    warn "$rel: not XML and plutil is missing, skipped"
  fi
done <<EOF_PL
$(files '*.plist')
EOF_PL
[ "$n" -gt 0 ] || echo "  (none)"

# 3. Swift sources
swift_list=$(files '*.swift')
if [ -n "$swift_list" ]; then
  echo "-- swift sources (target: iOS 16.4)"
  hits=0
  check_api() { # regex, label
    local out
    out=$(grep -nE --include='*.swift' -r "$1" "$dir" 2>/dev/null | grep -v '/\.theos/' | head -n 20 || true)
    if [ -n "$out" ]; then
      while IFS= read -r line; do
        warn "${line#"$dir"/}  <- $2"
        hits=$((hits + 1))
      done <<EOF_HITS
$out
EOF_HITS
    fi
  }
  check_api '@Observable([^A-Za-z]|$)'                  '@Observable needs iOS 17: use ObservableObject'
  check_api 'import[[:space:]]+SwiftData'               'SwiftData needs iOS 17'
  check_api 'ContentUnavailableView'                    'ContentUnavailableView needs iOS 17'
  check_api '\.sensoryFeedback'                         '.sensoryFeedback needs iOS 17: use UIImpactFeedbackGenerator'
  check_api '#Preview'                                  '#Preview needs Xcode 15 tooling: avoid'
  check_api '\.scrollTargetBehavior|\.scrollPosition\(' 'scroll target/position APIs need iOS 17'
  check_api 'onChange\(of:.*\{[[:space:]]*[A-Za-z_]+[[:space:]]*,[[:space:]]*[A-Za-z_]+[[:space:]]+in' 'two-parameter onChange needs iOS 17'
  [ "$hits" -gt 0 ] || ok "no iOS 17+ API patterns found"
  mains=$(grep -rE --include='*.swift' '^[[:space:]]*@main' "$dir" 2>/dev/null | grep -vc '/\.theos/' || true)
  if [ "${mains:-0}" -gt 1 ]; then warn "more than one @main found ($mains)"; fi
  while IFS= read -r f; do
    [ -s "$f" ] || fail "${f#"$dir"/}: empty Swift file"
  done <<EOF_SW
$swift_list
EOF_SW
fi

# 4. app project consistency (Theos application)
if [ -f "$dir/Makefile" ] && grep -q '^APPLICATION_NAME' "$dir/Makefile"; then
  echo "-- app project (Makefile + Info.plist + entitlements)"
  app=$(sed -n 's/^APPLICATION_NAME[[:space:]]*[:+?]*=[[:space:]]*//p' "$dir/Makefile" | head -n 1 | tr -d ' \t\r')
  info="$dir/Resources/Info.plist"
  if [ -f "$info" ]; then
    exe=$(plist_str "$info" CFBundleExecutable)
    if [ -z "$exe" ]; then
      fail "Resources/Info.plist: CFBundleExecutable missing"
    elif [ "$exe" = "$app" ]; then
      ok "APPLICATION_NAME and CFBundleExecutable match ($app)"
    else
      fail "name mismatch: APPLICATION_NAME=$app but CFBundleExecutable=$exe"
    fi
    for k in CFBundleIdentifier CFBundlePackageType MinimumOSVersion; do
      if [ -n "$(plist_str "$info" "$k")" ]; then ok "Info.plist has $k"; else fail "Info.plist: $k missing"; fi
    done
    minos=$(plist_str "$info" MinimumOSVersion)
    major="${minos%%.*}"
    case "$major" in
      ''|*[!0-9]*) ;;
      *) if [ "$major" -gt 16 ]; then warn "MinimumOSVersion $minos is above the phone's iOS 16.4.1"; fi ;;
    esac
  else
    fail "Resources/Info.plist not found"
  fi
  if [ -f "$dir/Entitlements.plist" ]; then
    ok "Entitlements.plist present"
  else
    fail "Entitlements.plist missing (needed to sign for TrollStore)"
  fi
  if grep -q 'Entitlements.plist' "$dir/Makefile"; then ok "Makefile signs with Entitlements.plist"; else warn "Makefile does not reference Entitlements.plist"; fi
  # literal source files named in *_FILES must exist
  while IFS= read -r tok; do
    case "$tok" in
      *'$'*|*'*'*|*'%'*|'\') continue ;;
      *.swift|*.m|*.mm|*.x|*.xm|*.c|*.cpp)
        if [ -f "$dir/$tok" ]; then ok "source exists: $tok"; else fail "Makefile lists $tok but the file does not exist"; fi ;;
    esac
  done <<EOF_TOK
$(grep -E '^[A-Za-z0-9_]+_FILES[[:space:]]*[:+?]*=' "$dir/Makefile" | sed 's/^[^=]*=//' | tr -s ' \t' '\n')
EOF_TOK
  # dry run only where Theos is installed
  if have make && { [ -n "${THEOS:-}" ] || [ -d /var/mobile/theos ]; }; then
    if (cd "$dir" && THEOS="${THEOS:-/var/mobile/theos}" make -n >/dev/null 2>&1); then ok "make -n dry run succeeded"; else warn "make -n failed (run it and read the first error)"; fi
  fi
fi

# 5. secrets
echo "-- secrets"
secret_re='sk-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|[Aa][Pp][Ii][_-]?[Kk][Ee][Yy][[:space:]]*[:=][[:space:]]*["'"'"'][A-Za-z0-9_-]{16,}'
found=$(grep -rIlE --exclude-dir=.git --exclude-dir=.theos --exclude-dir=trash --exclude-dir=backups -e "$secret_re" "$dir" 2>/dev/null || true)
if [ -n "$found" ]; then
  while IFS= read -r f; do fail "possible secret in ${f#"$dir"/}"; done <<EOF_SEC
$found
EOF_SEC
else
  ok "no obvious secrets"
fi

echo
printf 'Result: %s error(s), %s warning(s)\n' "$errors" "$warns"
if [ "$errors" -gt 0 ]; then exit 1; fi
exit 0
