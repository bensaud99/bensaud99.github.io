#!/usr/bin/env bash
# env-check.sh - report the device, jailbreak and toolchain state.
# Usage: env-check.sh [--strict]
#   --strict   exit 1 when a core build tool (make, ldid, zip) is missing
set -u

usage() { sed -n '2,4p' "$0" | sed 's/^# \{0,1\}//'; }

strict=0
case "${1:-}" in
  --strict) strict=1 ;;
  -h|--help) usage; exit 0 ;;
  "") ;;
  *) echo "env-check: unknown option: $1" >&2; usage >&2; exit 64 ;;
esac

KWWK_HOME="${KWWK_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"
missing_core=0

have() { command -v "$1" >/dev/null 2>&1; }
section() { printf '\n== %s ==\n' "$*"; }
tool() {
  if have "$1"; then
    printf '  ✅ %-9s %s\n' "$1" "$(command -v "$1")"
  else
    printf '  ❌ %-9s not found\n' "$1"
    if [ "${2:-}" = core ]; then missing_core=1; fi
  fi
}

section "System"
printf '  uname:  %s\n' "$(uname -a 2>/dev/null)"
if have sw_vers; then printf '  iOS:    %s\n' "$(sw_vers -productVersion 2>/dev/null)"; fi
printf '  user:   %s (uid %s)\n' "$(id -un 2>/dev/null)" "$(id -u 2>/dev/null)"
printf '  HOME:   %s\n' "${HOME:-unset}"
printf '  bash:   %s\n' "${BASH_VERSION:-unknown}"

section "Jailbreak"
if have jbroot; then
  printf '  ✅ jbroot   %s\n' "$(command -v jbroot)"
  if jr=$(jbroot / 2>/dev/null) && [ -n "$jr" ]; then
    printf '     jailbreak root: %s\n' "$jr"
  fi
else
  echo "  ℹ️  jbroot command not found (never hardcode /var/jb)"
fi
if [ -d /var/jb ]; then echo "  ℹ️  /var/jb exists on this device"; else echo "  ℹ️  /var/jb does not exist on this device"; fi

section "Theos"
theos="${THEOS:-/var/mobile/theos}"
if [ -d "$theos" ]; then
  printf '  ✅ Theos    %s\n' "$theos"
  if [ -z "${THEOS:-}" ]; then echo "  ℹ️  THEOS is not exported: run  export THEOS=$theos"; fi
  if grep -rIq roothide "$theos/makefiles" 2>/dev/null; then
    echo "  ✅ RootHide-aware makefiles found (THEOS_PACKAGE_SCHEME = roothide)"
  else
    echo "  ℹ️  no RootHide support found in $theos/makefiles"
  fi
  if [ -d "$theos/sdks" ]; then
    printf '  SDKs:   %s\n' "$(ls "$theos/sdks" 2>/dev/null | tr '\n' ' ')"
  else
    echo "  ⚠️  $theos/sdks not found"
  fi
else
  printf '  ❌ Theos not found at %s\n' "$theos"
fi

section "Core build tools"
tool make core
tool ldid core
tool zip core

section "Other tools"
for t in clang swift unzip tar git python3 plutil dpkg curl base64 shasum bash; do tool "$t"; done

section "kwwk"
printf '  KWWK_HOME: %s\n' "$KWWK_HOME"
if [ -w "$KWWK_HOME" ]; then echo "  ✅ writable"; else echo "  ❌ not writable"; fi

echo
if [ "$missing_core" -eq 1 ]; then
  echo "⚠️  core tools are missing (make, ldid and zip are needed to build an .ipa)"
  if [ "$strict" -eq 1 ]; then exit 1; fi
else
  echo "✅ core build tools present"
fi
exit 0
