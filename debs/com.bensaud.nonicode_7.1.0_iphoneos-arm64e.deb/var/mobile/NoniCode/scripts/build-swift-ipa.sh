#!/bin/bash
# build-swift-ipa.sh — Build a SwiftUI IPA manually on RootHide
#
# Theos's Swift pipeline requires `swift-build` (SwiftPM), which is NOT
# installed in this jailbreak's toolchain. This script bypasses Theos and
# compiles the Swift sources directly with swiftc, signs with ldid, and
# zips a TrollStore-ready IPA.
#
# Usage: build-swift-ipa.sh <project-dir> [output-name]
#
# Project layout expected:
#   <project-dir>/Sources/*.swift
#   <project-dir>/Resources/Info.plist
#   <project-dir>/Entitlements.plist   (optional)

set -euo pipefail

PROJECT_DIR="${1:-}"
OUTPUT_NAME="${2:-NoniCode}"

if [ -z "$PROJECT_DIR" ] || [ ! -d "$PROJECT_DIR" ]; then
  echo "Usage: $0 <project-dir> [output-name]" >&2
  exit 1
fi

SDK="${THEOS_SDK:-/var/mobile/theos/sdks/iPhoneOS16.5.sdk}"
DEPLOY_TARGET="${DEPLOY_TARGET:-16.0}"
MODULE_CACHE="/tmp/nonicode_module_cache"
BUILD_DIR="/tmp/nonicode_build_$$"
APP_NAME="$OUTPUT_NAME"

if [ ! -d "$SDK" ]; then
  echo "error: SDK not found at $SDK" >&2
  exit 1
fi

if [ ! -d "$PROJECT_DIR/Sources" ]; then
  echo "error: $PROJECT_DIR/Sources not found" >&2
  exit 1
fi

if [ ! -f "$PROJECT_DIR/Resources/Info.plist" ]; then
  echo "error: $PROJECT_DIR/Resources/Info.plist not found" >&2
  exit 1
fi

mkdir -p "$MODULE_CACHE" "$BUILD_DIR"

SWIFT_FILES=$(find "$PROJECT_DIR/Sources" -name '*.swift' -type f | sort)
if [ -z "$SWIFT_FILES" ]; then
  echo "error: no .swift files found in $PROJECT_DIR/Sources" >&2
  exit 1
fi

echo "==> Compiling $(echo "$SWIFT_FILES" | wc -l | tr -d ' ') Swift files..."
# shellcheck disable=SC2086
swiftc \
  -sdk "$SDK" \
  -target "arm64-apple-ios${DEPLOY_TARGET}" \
  -module-cache-path "$MODULE_CACHE" \
  -emit-executable \
  -parse-as-library \
  -O \
  -o "$BUILD_DIR/$APP_NAME" \
  $SWIFT_FILES

echo "==> Staging app bundle..."
STAGE_APP="$BUILD_DIR/$APP_NAME.app"
mkdir -p "$STAGE_APP"
cp "$BUILD_DIR/$APP_NAME" "$STAGE_APP/$APP_NAME"
chmod 755 "$STAGE_APP/$APP_NAME"
cp "$PROJECT_DIR/Resources/Info.plist" "$STAGE_APP/Info.plist"

if [ -d "$PROJECT_DIR/Resources" ]; then
  for item in "$PROJECT_DIR/Resources"/*; do
    [ -e "$item" ] || continue
    base=$(basename "$item")
    [ "$base" = "Info.plist" ] && continue
    cp -R "$item" "$STAGE_APP/"
  done
fi

echo "==> Signing with ldid..."
if [ -f "$PROJECT_DIR/Entitlements.plist" ]; then
  ldid -S"$PROJECT_DIR/Entitlements.plist" "$STAGE_APP/$APP_NAME"
else
  ldid -S "$STAGE_APP/$APP_NAME"
fi

echo "==> Packaging IPA..."
cd "$BUILD_DIR"
rm -rf Payload
mkdir Payload
cp -R "$STAGE_APP" Payload/
zip -qry "$APP_NAME.ipa" Payload
rm -rf Payload

echo "✅ IPA ready: $BUILD_DIR/$APP_NAME.ipa"
