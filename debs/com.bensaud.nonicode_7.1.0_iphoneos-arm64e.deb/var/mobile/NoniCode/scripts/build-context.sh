#!/usr/bin/env bash
# build-context.sh - merge CLAUDE.md, AGENTS.md and the skill index into one prompt file.
# Usage: build-context.sh [--full] [-o FILE]
#   --full     include every SKILL.md body, not just name + description
#   -o FILE    write to FILE (default: standard output)
set -eu

KWWK_HOME="${KWWK_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"

usage() { sed -n '2,5p' "$0" | sed 's/^# \{0,1\}//'; }

full=0
out=""
while [ $# -gt 0 ]; do
  case "$1" in
    --full) full=1; shift ;;
    -o)
      if [ $# -lt 2 ]; then usage >&2; exit 64; fi
      out="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "build-context: unknown argument: $1" >&2; usage >&2; exit 64 ;;
  esac
done

for need in CLAUDE.md AGENTS.md; do
  [ -f "$KWWK_HOME/$need" ] || { echo "build-context: missing $KWWK_HOME/$need" >&2; exit 1; }
done

# frontmatter value of a key (first match, single line)
fm() {
  awk -v key="$2" '
    /^---[[:space:]]*$/ { c++; next }
    c == 1 && index($0, key ":") == 1 { sub("^" key ":[[:space:]]*", ""); print; exit }
  ' "$1"
}

# everything after the closing --- of the frontmatter
body() {
  awk '
    /^---[[:space:]]*$/ && c < 2 { c++; next }
    c >= 2 { print }
  ' "$1"
}

emit() {
  cat "$KWWK_HOME/CLAUDE.md"
  printf '\n\n---\n\n'
  cat "$KWWK_HOME/AGENTS.md"
  printf '\n\n---\n\n# Skills\n\n'
  if [ "$full" -eq 0 ]; then
    printf 'When a skill matches the task, read its SKILL.md in full before acting.\n\n'
  fi
  for f in "$KWWK_HOME"/skills/*/SKILL.md; do
    [ -f "$f" ] || continue
    name=$(fm "$f" name)
    desc=$(fm "$f" description)
    if [ "$full" -eq 1 ]; then
      printf '## Skill: %s\n\n_Use when:_ %s\n\n' "$name" "$desc"
      body "$f"
      printf '\n\n'
    else
      printf -- '- **%s** (`skills/%s/SKILL.md`): %s\n' "$name" "$name" "$desc"
    fi
  done
}

if [ -n "$out" ]; then
  emit > "$out"
  echo "build-context: wrote $out ($(wc -c < "$out" | tr -d ' ') bytes)" >&2
else
  emit
fi
