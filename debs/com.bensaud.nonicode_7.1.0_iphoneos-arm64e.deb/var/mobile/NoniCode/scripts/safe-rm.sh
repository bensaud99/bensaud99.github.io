#!/usr/bin/env bash
# safe-rm.sh - move things to a restorable trash instead of deleting them.
# Usage: safe-rm.sh <path>...           move to trash
#        safe-rm.sh --list              list trash batches
#        safe-rm.sh --restore <batch>   put a batch back where it came from
#        safe-rm.sh --purge <batch>     delete a batch for good (needs KWWK_CONFIRMED=1)
set -eu

KWWK_HOME="${KWWK_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"
TRASH="$KWWK_HOME/trash"
TAB=$(printf '\t')

usage() { sed -n '2,6p' "$0" | sed 's/^# \{0,1\}//'; }

abspath() {
  local d b
  if [ "$1" = "/" ]; then printf '/\n'; return 0; fi
  d=$(dirname -- "$1"); b=$(basename -- "$1")
  d=$(cd "$d" 2>/dev/null && pwd -P) || return 1
  if [ "$d" = "/" ]; then printf '/%s\n' "$b"; else printf '%s/%s\n' "$d" "$b"; fi
}

is_protected() {
  local a="$1"
  case "$a" in
    /|//|/var|/var/mobile|/private|/private/var|/Applications|/Library|/etc|/System|/usr|/bin|/sbin) return 0 ;;
    /System/*|/usr/*|/bin/*|/sbin/*|/private/preboot|/private/preboot/*) return 0 ;;
    /var/containers/Bundle/Application/.jbroot*) return 0 ;;
    /var/mobile/Library|/var/mobile/Media) return 0 ;;
  esac
  if [ "$a" = "${HOME:-/nonexistent-home}" ]; then return 0; fi
  if [ "$a" = "$KWWK_HOME" ] || [ "$a" = "$TRASH" ]; then return 0; fi
  case "$a" in "$TRASH"/*) return 0 ;; esac
  case "$TRASH" in "$a"/*) return 0 ;; esac
  return 1
}

valid_batch() {
  case "$1" in
    ""|*/*|.*) echo "safe-rm: invalid batch name: $1" >&2; exit 64 ;;
  esac
}

if [ $# -lt 1 ]; then usage >&2; exit 64; fi

case "$1" in
  -h|--help) usage; exit 0 ;;

  --list)
    found=0
    for b in "$TRASH"/*/; do
      [ -f "${b}manifest.tsv" ] || continue
      found=1
      n=$(wc -l < "${b}manifest.tsv" | tr -d ' ')
      printf '%s\t%s item(s)\n' "$(basename "$b")" "$n"
    done
    if [ "$found" -eq 0 ]; then echo "trash is empty"; fi
    exit 0
    ;;

  --restore)
    [ $# -eq 2 ] || { usage >&2; exit 64; }
    batch="$2"; valid_batch "$batch"
    manifest="$TRASH/$batch/manifest.tsv"
    [ -f "$manifest" ] || { echo "safe-rm: no such batch: $batch" >&2; exit 1; }
    restored=0; failed=0
    while IFS="$TAB" read -r orig stored; do
      [ -n "$orig" ] || continue
      if [ -e "$orig" ] || [ -L "$orig" ]; then
        echo "safe-rm: already exists, not overwriting: $orig" >&2
        failed=$((failed + 1)); continue
      fi
      mkdir -p "$(dirname -- "$orig")"
      mv -- "$stored" "$orig"
      restored=$((restored + 1))
    done < "$manifest"
    echo "safe-rm: restored $restored item(s), $failed skipped"
    if [ "$failed" -eq 0 ]; then mv "$TRASH/$batch" "$TRASH/$batch.restored"; exit 0; fi
    exit 1
    ;;

  --purge)
    [ $# -eq 2 ] || { usage >&2; exit 64; }
    batch="$2"; valid_batch "$batch"
    [ -d "$TRASH/$batch" ] || { echo "safe-rm: no such batch: $batch" >&2; exit 1; }
    if [ "${KWWK_CONFIRMED:-0}" != "1" ]; then
      echo "safe-rm: permanent delete needs the user's explicit yes (then set KWWK_CONFIRMED=1)" >&2
      exit 2
    fi
    rm -rf -- "${TRASH:?}/$batch"
    echo "safe-rm: purged $batch"
    exit 0
    ;;

  -*) echo "safe-rm: unknown option: $1" >&2; usage >&2; exit 64 ;;
esac

batch="$(date +%Y%m%d-%H%M%S)-$$"
dir="$TRASH/$batch"
rc=0; n=0
mkdir -p "$dir/files"
: > "$dir/manifest.tsv"

for p in "$@"; do
  if [ ! -e "$p" ] && [ ! -L "$p" ]; then
    echo "safe-rm: not found, skipping: $p" >&2; continue
  fi
  a=$(abspath "$p") || { echo "safe-rm: cannot resolve: $p" >&2; rc=1; continue; }
  if is_protected "$a"; then
    echo "safe-rm: protected path, refusing: $a" >&2; rc=1; continue
  fi
  stored="$dir/files/${a#/}"
  mkdir -p "$(dirname -- "$stored")"
  mv -- "$a" "$stored"
  printf '%s\t%s\n' "$a" "$stored" >> "$dir/manifest.tsv"
  n=$((n + 1))
done

if [ "$n" -eq 0 ]; then
  rm -f "$dir/manifest.tsv"
  rmdir "$dir/files" "$dir" 2>/dev/null || true
  echo "safe-rm: nothing moved" >&2
  if [ "$rc" -ne 0 ]; then exit "$rc"; fi
  exit 1
fi

echo "safe-rm: moved $n item(s) to trash, batch: $batch"
echo "safe-rm: restore with: scripts/safe-rm.sh --restore $batch"
exit "$rc"
